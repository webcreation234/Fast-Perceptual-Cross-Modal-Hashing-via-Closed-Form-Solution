function [ImgToTxt,TxtToImg] = DEMO(trainLabel, param, dataset)
seed = 0;
rng('default');
rng(seed);

X1 = dataset.XDatabase;
X2 = dataset.YDatabase;
XTest = dataset.XTest;
YTest = dataset.YTest;
testL = dataset.testL;
databaseL = dataset.databaseL;
lambda=param.lambda;
top_K=1000;
[d1,~] = size(X1');
[d2,~] = size(X2');

bit = param.bit;
numTrain = size(trainLabel, 1);
c = size(trainLabel,2);


%--------------------------------initial------------------------------------
H= ones(bit,numTrain);
H=sgn(H);



W1=randn(bit,d1);
W2=randn(bit,d2);


tic
for epoch = 1:1
%For FPCH, since it is solved using a closed-form solution, no additional iterations are needed. For other offline models, the number of epochs is generally set to 10.

    B1_tmp=(W1*X1');
    B1=constraint(B1_tmp,bit,numTrain)';
    B1 = dct(B1.').';%dct
    B2_tmp=(W2*X2');
    B2=constraint(B2_tmp,bit,numTrain)';
    B2 = dct(B2.').';%dct
    H=sgn((B1*trainLabel*trainLabel'+B2*trainLabel*trainLabel'));

end

toc

    %-----------------real-time evaluation----------------------------
    P1=H*X1/(X1'*X1+lambda*eye(d1));
    P2=H*X2/(X2'*X2+lambda*eye(d2));
    tBX = sign(P1*XTest')';
    tBY = sign(P2*YTest')';
    HH=H';HH(HH<0) = 0;
    ti_H = compactbit(HH);
    tBX(tBX<0) = 0;
    tBX = compactbit(tBX);
    tBY(tBY<0) = 0;
    tBY = compactbit(tBY);
    Dhamm = hammingDist(tBX, ti_H);
    [~, HammingRank]=sort(Dhamm,2);
    out.MAP_test(1) = cal_mAP(databaseL,testL,HammingRank);
    [out.Image_VS_Text_precision, out.Image_VS_Text_recall] = precision_recall(HammingRank',databaseL,testL);
    out.Image_To_Text_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
    Dhamm = hammingDist(tBY, ti_H);
    [~, HammingRank]=sort(Dhamm,2);
    out.MAP_test(2) = cal_mAP(databaseL,testL,HammingRank);
    [out.Text_VS_Image_precision, out.Text_VS_Image_recall] = precision_recall(HammingRank', databaseL,testL);
    out.Text_To_Image_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
    ImgToTxt=out.MAP_test(1);
    TxtToImg=out.MAP_test(2);
    fprintf('...iter:%d,   i2t:%.4f,   t2i:%.4f\n',epoch, ImgToTxt, TxtToImg)
 
    i2t_pre=out.Image_VS_Text_precision;
    i2t_rec=out.Image_VS_Text_recall;
    i2t_pre_top=out.Image_To_Text_Precision;
    t2i_pre=out.Text_VS_Image_precision;
    t2i_rec=out.Text_VS_Image_recall;
    t2i_pre_top=out.Text_To_Image_Precision;

end




