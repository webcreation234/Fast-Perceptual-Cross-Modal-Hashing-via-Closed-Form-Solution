clear all
warning off
addpath(genpath(fullfile('utils/')));
addpath(genpath(fullfile('dataset/')));
seed = 0;
rng('default')
rng(seed);




%----------------------parameters setting-------------------

%-----------------method parameters
bits = [32,64,96,128];
nb = numel(bits);

param.bits = bits;
param.method = 'FPCH';


dataname = 'flickr-25k';
param.dataname = dataname;
lambda =1e-2;




par_4 = numel(lambda);


%load dataset
dataset = load_data(dataname);
n_anchors = 1500;
rbf2;
total_res=[];
% run algorithm
for i = 1: nb
            for jjj=1:par_4
                
                fprintf('...method: %s\n', param.method);
                fprintf('...bit: %d\n', bits(i));
                param.bit = bits(i);
                param.lambda= lambda(jjj)            
                trainL = dataset.databaseL;
                trainL = normr(trainL);              
                [ImgToTxt,TxtToIm]=DEMO(trainL, param, dataset);
                total_res = [total_res;ImgToTxt,TxtToIm, param.bit, param.lambda];
                
            end
        end

save([dataname, num2str('_result'),'.mat'], 'total_res');


